﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using ReenWise.Domain.Interfaces;

namespace ReenWise.Domain.Models.Mirror
{
    public class Manufacturer : EntityBase
    {
        [Required] 
        [StringLength(128)]
        public string Name { get; set; }
        public ICollection<Model> Models { get; set; }
        public ICollection<Equipment> Equipment { get; set; }  
        public ICollection<Vehicle> Vehicle { get; set; }  
    }
}
