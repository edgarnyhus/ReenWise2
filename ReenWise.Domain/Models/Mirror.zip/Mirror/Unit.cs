﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using ReenWise.Domain.Interfaces;

namespace ReenWise.Domain.Models.Mirror
{
    public class Unit : EntityBase
    {
        [StringLength(32)]
        public string? SerialNumber { get; set; }
        public string? Type { get; set; }            // "type": "Abax5"
        [StringLength(64)]
        public string? Health { get; set; }          // "health": "Healthy" - should be a HealthType
        [Required]
        [StringLength(64)]
        public string Status { get; set; }           //"status": "Active" - should be a StatusType
        public Guid? EquipmentId { get; set; }
        public Guid? VehicleId { get; set; }
    }
}
