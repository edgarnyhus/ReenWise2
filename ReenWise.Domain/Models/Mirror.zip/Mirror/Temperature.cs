﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using ReenWise.Domain.Interfaces;

namespace ReenWise.Domain.Models.Mirror
{
    public class Temperature : EntityBase
    {
        [Required]
        public float Value { get; set; }
        [Required]
        public DateTime Timestamp { get; set; }
        public Equipment? Equipment { get; set; }
        public Vehicle? Vehiicle { get; set; }
    }
}
