﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ReenWise.Domain.Interfaces;

namespace ReenWise.Domain.Models.Mirror
{
    public class Model : EntityBase
    {
        [Required]
        [StringLength(128)]
        public string Name { get; set; }
        [StringLength(32)]
        public string? SerialNumber { get; set; }
        [StringLength(512)]
        public string? Description { get; set; }
        public float? Weight { get; set; }
        public float? HHeight { get; set; }
        public float? Length { get; set; }
        public float? Width { get; set; }
        public float? Volume { get; set; }
        [StringLength(256)]
        public string? Attachment { get; set; }

        public Manufacturer? Manufacturer { get; set; }
        public ICollection<Equipment>? Equipments { get; set; }
        public ICollection<Vehicle>? Vehicles { get; set; }
    }
}
