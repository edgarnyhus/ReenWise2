﻿#nullable enable
using ReenWise.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Text;

namespace ReenWise.Domain.Models.Mirror
{
    public class Equipment : EntityBase
    {
        [Required]
        [StringLength(128)]
        public string Alias { get; set; }
        [StringLength(32)]
        public string? SerialNumber { get; set; }
        [Required]
        public Model Model { get; set; }
        public Guid modelId { get; set; }
        public OperatingHours? OperatingHours { get; set; }
        public Unit? Unit { get; set; }
        public ICollection<Location> Locations { get; set; }
        [Required]
        public Organization Organization { get; set; }
        public OperatingHours? InitialOperatingHours { get; set; }
        public ICollection<Temperature>? Temperatures { get; set; }
        public string? Notes { get; set; }
        public Manufacturer? Manufacturer { get; set; }
    }
}