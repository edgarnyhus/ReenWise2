﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using ReenWise.Domain.Interfaces;

namespace ReenWise.Domain.Models.Mirror
{
    public class Vehicle : EntityBase
    {
        [Required]
        [StringLength(128)]
        public string Alias { get; set; }
        public Manufacturer? Manufacturer { get; set; }
        [Required] 
        public Model Model { get; set; }
        [Required] 
        public LicensePlate LicensePlate { get; set; }
        public DateTime RegisteredAt { get; set; }
        [StringLength(128)]
        public Guid? CommercialClass { get; set; }    // "commercial_class": "Commercial",
        public Unit? Unit { get; set ; }
        public ICollection<Location> Locations { get; set; }
        public Driver? Driver { get; set; }
        [Required] 
        public Organization Organization { get; set; }
        public OdoMeter? OdoMeter { get; set; }
        [StringLength(1024)]
        public string? Notes { get; set; }
        public ICollection<Temperature>? Temperatures { get; set; }
        [StringLength(32)]
        public string? FuelType { get; set; }        // "fuel_type": "Petrol" - should be a FuelType
        public float? EngineSize { get; set; }
        [StringLength(32)]
        public string? Color { get; set; }
        public float? Co2Emissions { get; set; }
    }
}
